#!/bin/bash

cd /home/margo/neural-style
export PATH=$PATH:/home/margo/torch/install/bin
export LD_LIBRARY_PATH=/home/margo/torch/install/lib

