require 'test_helper'

class ProcessImageJobTest < ActiveJob::TestCase
  # test "the truth" do
  #   assert true
  # end
end
