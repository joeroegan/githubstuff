require 'test_helper'

class QueueImageTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
