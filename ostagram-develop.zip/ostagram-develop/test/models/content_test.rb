require 'test_helper'

class ContentImageTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
