require 'test_helper'

class S1tyleTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
