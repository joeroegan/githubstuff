require 'test_helper'

class PimageTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
