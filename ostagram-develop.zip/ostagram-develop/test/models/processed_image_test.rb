require 'test_helper'

class ProcessedImageTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
