require 'test_helper'

class StyleImageTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
