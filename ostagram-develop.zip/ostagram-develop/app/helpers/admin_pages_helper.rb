module AdminPagesHelper
end
