module StaticPagesHelper

end
